import numpy as np

"""
Main file containing all the linear algorithms
"""
"""
gauss_elim solves equations of the form X = AY, where X and Y are vectors and A is a matrix,assuming consistent and unique solution

"""
def gauss_elim(A,y):

    N = A.shape[0]

    # Gaussian elimination
    for m in range(N):

        # Divide by the diagonal element
        div = A[m,m]
        A[m,:] /= div
        y[m] /= div

        # Now subtract from the lower rows
        for i in range(m+1,N):
            mult = A[i,m]
            A[i,:] -= mult*A[m,:]
            y[i] -= mult*y[m]

    # Backsubstitution
    x = np.empty(N,float)
    for m in range(N-1,-1,-1):
        x[m] = y[m]
        for i in range(m+1,N):
            x[m] -= A[m,i]*x[i]

    return x

"""
We just apply the idea of partial pivoting in the earlier
"""

def gauss_elim_partial_pivot(A,y):

    N = A.shape[0]

    for m in range(0,N):

        # We switch rows with the maximal element ( Choosing a pivot )
        for i in range(m, N):

            if abs(A[i][m]) > abs(A[m][m]):   
                A1 = np.copy(A[m])
                y1 = np.copy(y[m])
                A[m] = np.copy(A[i])
                y[m] = np.copy(y[i])
                A[i] = np.copy(A1)
                y[i] = np.copy(y1)
            else:
                continue

        # Divide by the diagonal element            
        div = A[m,m]
        A[m,:] /= div
        y[m] /= div

        # Now subtract from the lower rows
        for i in range(m+1,N):
            mult = A[i,m]
            A[i,:] -= mult*A[m,:]
            y[i] -= mult*y[m]
        
    # Backsubstitution
    x = np.empty(N,float)
    for m in range(N-1,-1,-1):
        x[m] = y[m]
        for i in range(m+1, N):
            x[m] -= A[m,i]* x[i]

    return x


"""
Instead of working with every row we will check only b rows up and b rows down, as most all other elements above/below are zero
"""

def gauss_elim_banded(A,v,b):

    N = A.shape[0]

    for m in range(N):

        # Divide by the diagonal element
        div = A[m,m]
        A[m,:] /= div
        v[m] /= div

        N1 = min(m + 1 + b, N)

        # Now subtract from the lower rows
        for i in range(m+1,N1):
            mult = A[i,m]
            A[i,:] -= mult*A[m,:]
            v[i] -= mult*v[m]

    # Backsubstitution
    x = np.empty(N,float)
    for m in range(N-1,-1,-1):
        x[m] = v[m]
        for i in range(m+1,N):
            x[m] -= A[m,i]*x[i]

    return x



"""
QR decomposition using Modified Gram schmidt orthogonalization
"""

def Modified_Gram_schmidt(A):

    V = []
    N = A.shape[0]
    Q = np.zeros([N,N])
    R = np.zeros([N,N])

    for i in np.arange(0,N):
        V.append(A[:,i])


    for i in np.arange(0,N):

        R[i][i] = np.linalg.norm(V[i])
        Q[:, i]  = V[i]/ R[i][i]

        for m in np.arange(i+1,N):
            R[i][m] = np.dot(Q[:, i], V[m])
            V[m] = V[m] - R[i][m] * Q[:, i]

    return Q, R



"""
 The function Eigen determines Eigen vectors and Eigen values using Qr decompsition
"""

def Eigen(A, error, N_max):

    n = A.shape[0]
    V = np.array(np.identity(n))
    A1 = np.copy(A)

    for m in np.arange(0,N_max):
        q, N = Modified_Gram_schmidt(A1)
    

    # Iteration steps
        A1 = np.dot(N,q)
        V = np.dot(V,q)
        A2 = np.copy(A1)

    # making the diagonal elements 0, to check for only the off diagonal elements
        for i in np.arange(0,n):
            A2[i][i] = 0

        e = abs(A2).max()

        if (e < error):
            break
    
    return A1, V





from numpy import copy

def banded(Aa,va,up,down):

    # Copy the inputs and determine the size of the system
    A = copy(Aa)
    y = copy(va)
    N = N

    # Gaussian elimination
    for m in range(N):

        # Normalization factor
        div = A[up,m]

        # Update the vector first
        y[m] /= div
        for k in range(1,down+1):
            if m+k<N:
                y[m+k] -= A[up+k,m]*y[m]

        # Now normalize the pivot row of A and subtract from lower ones
        for i in range(up):
            m = m + up - i
            if m<N:
                A[i,m] /= div
                for k in range(1,down+1):
                    A[i+k,m] -= A[up+k,m]*A[i,m]

    # Backsubstitution
    for m in range(N-2,-1,-1):
        for i in range(up):
            m = m + up - i
            if m<N:
                y[m] -= A[i,m]*y[m]

    return y






            
        

        


