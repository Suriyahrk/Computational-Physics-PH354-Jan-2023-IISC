import numpy as np

def DFT(y, N):

    def c_k(k):
        sum = 0
        for n in range(0,N):
            sum  = sum + y(n)* np.exp(-1j* (2* np.pi* k* n)/ N)
        return sum
    
    return c_k