import numpy as np
import sympy as smp
import matplotlib.pyplot as plt
import scipy.constants as sc
import sys
sys.path.insert(0,'.')
from Root_finding import *
from linear_alg import *

# part - b

L = 5*10**(-10)               # in m
a = 10* sc.elementary_charge # in V
M = sc.electron_mass        # in Kg
e = sc.elementary_charge    # in Coulomb
hbar = sc.hbar              # in Js^-1


"""
H_nm is the function returning the n,m element of the H matrix

"""
def H_nm(n,m):

    if m == n :
        return ( hbar**2 * n**2 * np.pi**2 ) / (2* M* L**2) + a/2

    elif (m%2 == 0 and n%2 == 0) or (m%2 == 1 and n%2 == 1):
        return 0
    
    else:
        return -8*a*m*n / (np.pi**2 * (m**2 - n**2 )**2 ) 
    

# part - c

"""
Creating 10 x 10 matrix of H
"""
H = np.zeros((10,10))

for m in np.arange(0,10):
    for n in np.arange(0,10):
        H[n][m] = H_nm(n+1,m+1)


Eigenvals = np.linalg.eigvalsh(H)

for i in np.arange(0,10):
    print(f" The energy of {i}th state is {Eigenvals[i]/sc.electron_volt}")

# Output 

"""
Energy of first 10 energy states in eV

The energy of 0th state is 5.836376902706761
The energy of 1th state is 11.181092906297504
The energy of 2th state is 18.662891578380496
The energy of 3th state is 29.14419775590052
The energy of 4th state is 42.65507484533357
The energy of 5th state is 59.18525781933309
The energy of 6th state is 78.72936018850429
The energy of 7th state is 101.28548383437395
The energy of 8th state is 126.8513857454442
The energy of 9th state is 155.55532885350135

"""



H_100 = np.zeros((100,100))

for m in np.arange(0,100):
    for n in np.arange(0,100):
        H_100[n][m] = H_nm(n+1,m+1)

Eigenvals_100 = np.linalg.eigvalsh(H_100)

for i in np.arange(0,100):
   print(f" The energy of {i}th state is {Eigenvals_100[i]/sc.electron_volt}")

"""
The output is in a seperate text file. We can see the Eigenvalues match up quite accurately.
"""

# Part - e


Eigenvectors = np.linalg.eig(H)[1]


"""
We multiply by a factor of np.sqrt(2/L) to ensure normalization for the basis wavefunction
"""

def psi_0(x):
    temp0 = 0
    for i in np.arange(0,10):
        temp0 = temp0 + Eigenvectors[0][i]* (( np.sqrt(2/L)) * np.sin ( (i+1)*np.pi*x / L) )

    return temp0**2

def psi_1(x):
    temp1 = 0
    for i in np.arange(0,10):
        temp1= temp1 + Eigenvectors[1][i]*( ( np.sqrt(2/L))* np.sin( (i+1)*np.pi*x / L) )

    return temp1**2

def psi_2(x):
    temp2 = 0
    for i in np.arange(0,10):
        temp2= temp2 + Eigenvectors[2][i]* ( ( np.sqrt(2/L)) * np.sin((i+1)*np.pi*x / L) )

    return temp2**2

X = np.linspace(0,L,100)
Psi_0 = psi_0(X)
Psi_1 = psi_1(X)
Psi_2 = psi_2(X)

plt.plot(X,Psi_0)
plt.plot(X,Psi_1)
plt.plot(X,Psi_2)
plt.xlabel("X-coordinate")
plt.ylabel("Wave-function")
plt.title("Probability density of first 3 states")
plt.legend(["Psi_0"," Psi_1","Psi_2"])
 # plt.savefig("q16-part-e.png")
plt.show()

from gauss_int import *

Norm0 = GQ(0, L, psi_0, 10 )
Norm1 = GQ(0, L, psi_1, 10 )
Norm2 = GQ(0, L, psi_2, 10 )

print(f"The normalization of the first three ground states are Norm of psi_0 = {Norm0} \n Norm of psi_1 = {Norm1} \n Norm of psi_2 = {Norm2}")

# Output
  
"""
The normalization of the first three ground states are

Norm of psi_0 = 1.0001499455150868 
Norm of psi_1 = 0.9940887919144418
Norm of psi_2 = 1.1422268755435951

We can see the values are very closed to 1, hence the wavefunctions are normalized
"""



